ANDROZOO = {
    "dex": {"date": "2016-04-05 17:58:46", "size": 4765888},
    "sha1": "9c14d537a7adb4cfc43d291352f73e05e0ccdd4a",
    "apk": {"size": 10386469},
    "vt": {"date": "2016-06-15 15:26:44", "score": 0},
    "pkg": {"code": 121, "name": "com.zte.bamachaye"},
    "sha256": "0000003b455a6c7af837ef90f2eaffd856e3b5cf49f5e27191430328de2fa670",
    "markets": "anzhi",
    "md5": "3edfc78ab53521942798ad551027d04f",
}
